package com.sreenadh.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreenadh.dao.CustomerDAO;
import com.sreenadh.models.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{

	public CustomerServiceImpl() {
		
		super();
		System.out.println("######################### CustomerServiceImpl service created *****************");
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private CustomerDAO customerDao;
	
	@Override
	public List<Customer> retrieveAll() {
		// TODO Auto-generated method stub
		return customerDao.retrieveAll();
	}

	@Override
	public List<Customer> findCustomer(Integer custId) {
		// TODO Auto-generated method stub
		return customerDao.findCustomer(custId);
	}

	@Override
	public Optional<Customer> findByEmail(String email) {
		// TODO Auto-generated method stub
		return customerDao.findByEmail(email);
	}

	@Override
	public Optional<Customer> findByName(String name) {
		// TODO Auto-generated method stub
		return customerDao.findByName(name);
	}

	@Override
	public void deleteCustomer(Integer custId) {
		// TODO Auto-generated method stub
		customerDao.deleteCustomer(custId);
	}

	@Override
	public void addCustomer(Customer c) {
		// TODO Auto-generated method stub
		customerDao.addCustomer(c);
	}

}
