package com.sreenadh;

import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AopLoggerAspect {

	static Logger log = Logger.getLogger("AopLoggerAspect");
	
	@Before("execution (* com.sreenadh.controllers.*.*(..) )")
	public void logBefore(JoinPoint pt) {
		log.info("Calling method: "+pt.getSignature().getName());
	}
	
	@After("execution (* com.sreenadh.controllers.*.*(..) )")
	public void logAfter(JoinPoint jp) {
		log.info("after method: "+jp.getSignature().getName());
	}
}
