package com.sreenadh.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import com.sreenadh.models.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	List<Customer> customerList = null;
	
	public CustomerDAOImpl() {
		
		super();
		System.out.println("********************** CustomerDAOImpl class created *****************");
		// TODO Auto-generated constructor stub
	}

	@PostConstruct
	public void init() {
		customerList = new ArrayList<>();
		customerList.add(new Customer(101,"Sreenadha","Gottipati", 9848996352L,"sreenathkumar433@gmail.com"));
		customerList.add(new Customer(102,"Srikanth","Gottipati", 12131312L,"srikanth@gmail.com"));
		customerList.add(new Customer(103,"ramasubbanaidu","Gottipati", 9874899663L,"sreenathkumar433@gmail.com"));
		customerList.add(new Customer(104,"kameswari","Gottipati", 9848996352L,"sreenathkumar433@gmail.com"));
		customerList.add(new Customer(105,"srilakshmi","Gottipati", 9848996352L,"lakshmisarala@gmail.com"));
	}
	
	@Override
	public List<Customer> retrieveAll() {
		// TODO Auto-generated method stub
		return customerList;
	}

	@Override
	public List<Customer> findCustomer(Integer custId) {
		// TODO Auto-generated method stub
		return customerList.stream().filter(x -> x.getCustId().equals(custId)).collect(Collectors.toList());
	}

	@Override
	public Optional<Customer> findByEmail(String email) {

		return customerList.stream().filter(x -> x.getEmail().equalsIgnoreCase(email)).findFirst();
	}

	@Override
	public  Optional<Customer> findByName(String name) {
		// TODO Auto-generated method stub
		return customerList.stream().filter(x -> { return (x.getFirstName().equalsIgnoreCase(name) || x.getLastName().equalsIgnoreCase(name));}).findFirst();
	}

	@Override
	public void deleteCustomer(Integer custId) {
		// TODO Auto-generated method stub
		List<Customer> customers = findCustomer(custId);
		if(customers!= null && !customers.isEmpty())
		customerList.remove(customers.get(0));
	}
	
	public void addCustomer(Customer cust) {
		customerList.add(cust);
	}

}
