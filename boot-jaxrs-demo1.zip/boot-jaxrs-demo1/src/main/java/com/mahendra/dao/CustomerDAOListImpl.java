package com.mahendra.dao;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mahendra.models.Customer;
import com.mahendra.repository.CustomerRepository;

@Repository
public class CustomerDAOListImpl implements CustomerDAO {

	@Autowired 
	private CustomerRepository customerRepository;
	
	private List<Customer> customers = new LinkedList<Customer>();
	
//	@PostConstruct
//	private void init() {
//		customers.add(new Customer(101,"Vijay", "Mallya", "765765765", "vmallya@yahoo.com"));
//		customers.add(new Customer(102,"Siddharth","Mallya","6879878911","smallya@yahoo.com"));
//		customers.add(new Customer(103,"Deepika","Padukon","6465465","deep@yahoo.com"));
//		
//	}
	
	@Override
	public List<Customer> findAllCustomers() {
		customers = customerRepository.findAll();
		return customers;
	}

	@Override
	public List<Customer> findByName(String name) {
		customers = customerRepository.findAll();
		return customers.stream()
					.filter((x)->{ return x.getLastName().contains(name) || x.getFirstName().contains(name);})
					.collect(Collectors.toList());
	}

	@Override
	public void save(Customer customer) {
		customerRepository.save(customer);
	}

	@Override
	public Optional<Customer> findByEmail(String email) {
		customers = customerRepository.findAll();
		return customers
					.stream()
					.filter((x)
						->x.getEmail().equalsIgnoreCase(email))
					.findFirst();
	}

	@Override
	public void update(Customer customer) {
		String email = customer.getEmail();
		Optional<Customer> cust = findByEmail(email);
		if(!cust.isPresent()) {
			throw new RuntimeException("No record found!");
		}
		Customer oldCustomer = cust.get();
		oldCustomer.setFirstName(customer.getFirstName());
		oldCustomer.setLastName(customer.getLastName());
		oldCustomer.setPhoneNo(customer.getPhoneNo());
		
		customerRepository.save(oldCustomer);
	}

	@Override
	public Customer findById(Integer id) {
		 Optional<Customer> cus = customerRepository.findById(id);
		 if(cus.isPresent())
			 return cus.get();
		 else return new Customer();
	}

	@Override
	public void delete(Integer id) {
		 Optional<Customer> cus = customerRepository.findById(id);
		 if(cus.isPresent())
			 customerRepository.delete(cus.get());
	}

	

	
}
